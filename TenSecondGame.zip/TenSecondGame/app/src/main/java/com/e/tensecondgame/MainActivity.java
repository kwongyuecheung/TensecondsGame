//**********************************
// 課題名 : TenSecondGame
// クラス : SE1A
// 作成者 : Kwong Yue Cheungコウユウショウ
// 作成日 : 2020/11/24
//**********************************
package com.e.tensecondgame;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity {
    //メッセージ表示用テキストビュー
    private TextView messageTextView;
    //タイマー表示用テキストビュー
    private TextView timerTextView;
    //タイマー表示用書式(例:12.3 秒)
    private SimpleDateFormat timerFormat = new SimpleDateFormat("ss.S 秒");
    //タイマーカウント用ハンドラー生成
    private Handler timerHandler = new Handler();
    //タイマー用カウンタ, 秒間隔(ミリ秒)
    private int count, interval;
    //スタートボタン
    private Button startButton;
    //ストップボタン
    private Button stopButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //メッセージ表示用テキストビュー関連付け
        messageTextView = findViewById(R.id.message_text);
        //タイマー表示用テキストビュー関連付け
        timerTextView = findViewById(R.id.timer_text);
        //タイマー初期テキスト設定（0 秒）
        timerTextView.setText(timerFormat.format(0));
        //タイマーカウンタ初期化
        count = 0;
        //カウントアップ間隔（0.1 秒）設定
        interval = 100;
        //スタートボタン関連付け
        startButton = findViewById(R.id.start_button);
        //ストップボタン関連付け
        stopButton = findViewById(R.id.stop_button);
        //起動時ストップボタン無効
        stopButton.setEnabled(false);

        //スタートボタンクリックイベント
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timerHandler.post(runnable);
                startButton.setEnabled(false);
                stopButton.setEnabled(true);
                messageTextView.setText(getString(R.string.run_message));
            }
        });
        stopButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                timerHandler.removeCallbacks(runnable);
                //停止した時間が 10 秒の場合
                if(count == 100){
                    messageTextView.setText(getString(R.string.clear_message));
                }else{
                    messageTextView.setText(getString(R.string.retry_message));
                }
                //カウンタリセット
                count = 0;
                timerTextView.setVisibility(View.VISIBLE);
                startButton.setEnabled(true);
                stopButton.setEnabled(false);
            }
        });
    }
    private Runnable runnable = new Runnable() {
        //タイマー処理
        @Override
        public void run() {
            count++; //1 = 0.1 秒
            if(count >= 3000){
                timerTextView.setVisibility(View.INVISIBLE);
            }
            timerTextView.setText(timerFormat.format(count*100));
            timerHandler.postDelayed(this, interval);
        }
    };
}